fn main(){
    for i in 1..101 {
        let v = 98;
        if i < 10 {
            let if_in_for = 12;
        } else {
            let else_in_for = 15;
        }
    }
    let a = 45 + 50;
}
#EOF
