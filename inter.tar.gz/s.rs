// This is a comment, and is ignored by the compiler
// You can test this code by clicking the "Run" button over there ->
// or if you prefer to use your keyboard, you can use the "Ctrl + Enter" shortcut

// This code is editable, feel free to hack it!
// You can always return to the original code by clicking the "Reset" button ->

// This is the main function
fn main (){
    // Statements here are executed when the compiled binary is called

    // Print text to the console
    println!("Hello World!");
    let a
    let a = 5;
    let n=10;
    let x = 87;

    let floatyfloaty = 97.42;
    let crazychar = 'c';
    let crazystrings = "gatetohell";
    for i in 1..101 {
        let v = 98923;
        let crazychar = 'c';
        if i < 10 {
            println!("fizzbuzz");
        } else {
            println!("{}", n);
        }
    }
    while n < 101 {
        if n -1 ==5  {
            println!("fizzbuzz");
        } else {
            println!("{}", n);
        }

    // Increment counter
    n= n+ 1;
    }
} #EOF

// let n = 10;
    // while n < 101 {
    //     if n ==5  {
    //         println!("fizzbuzz");
    //         let if_in_while = 15;
    //     } else {
    //         let else_in_while = 25;
    //     }
    // // Increment counter
    // n= n+ 1;
    // }

    for i in 1..101 {
        let v = 98;
        if i < 10 {
            let if_in_for = 12;
        } else {
            let else_in_for = 15;
        }
    }